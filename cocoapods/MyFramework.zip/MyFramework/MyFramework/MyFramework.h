//
//  MyFramework.h
//  MyFramework
//
//  Created by Anurag Ajwani on 29/09/2018.
//  Copyright © 2018 Anurag Ajwani. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MyFramework.
FOUNDATION_EXPORT double MyFrameworkVersionNumber;

//! Project version string for MyFramework.
FOUNDATION_EXPORT const unsigned char MyFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyFramework/PublicHeader.h>


